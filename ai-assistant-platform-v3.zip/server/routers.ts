import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  saveChatMessage,
  getChatHistory,
  getAvailableVpnNodes,
  claimVpnNode,
  getUserVipStatus,
  updateUserTheme,
} from "./db";
import { extendedRouter } from "./routers-extended";
import { enterpriseRouter } from "./routers-enterprise";
import { streamingRouter } from "./routers-streaming";
import { callAIWithFallback, getAvailableProviders } from "./ai-service";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // AI 聊天相关（使用真实 AI 服务）
  chat: router({
    sendMessage: protectedProcedure
      .input(z.object({ prompt: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const { prompt } = input;
        const userId = ctx.user?.id;

        if (!userId) {
          throw new Error("User not authenticated");
        }

        // 保存用户消息
        await saveChatMessage({
          userId,
          role: "user",
          content: prompt,
        });

        try {
          // 调用真实 AI 服务
          const aiResult = await callAIWithFallback(
            [
              {
                role: "system",
                content: "你是一个有效率的 AI 助手。你的名字是 A，是一个集成全球多个 AI 的智能助手。请用中文回答。",
              },
              {
                role: "user",
                content: prompt,
              },
            ],
            { preferredProvider: "manus" }
          );

          // 保存 AI 响应
          await saveChatMessage({
            userId,
            role: "ai",
            content: aiResult.content,
            aiModel: aiResult.model,
          });

          return {
            content: aiResult.content,
            success: true,
            model: aiResult.model,
            provider: aiResult.provider,
          };
        } catch (error) {
          console.error("[Chat API] Error:", error);
          // 错误回滚，返回错误信息
          const errorMessage = `抱歉，AI 服务暂时不可用。错误: ${(error as Error).message}`;
          
          await saveChatMessage({
            userId,
            role: "ai",
            content: errorMessage,
            aiModel: "error",
          });

          throw error;
        }
      }),

    getHistory: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }))
      .query(async ({ input, ctx }) => {
        const userId = ctx.user?.id;

        if (!userId) {
          throw new Error("User not authenticated");
        }

        const history = await getChatHistory(userId, input.limit);
        return history;
      }),
  }),

  // VPN 相关
  vpn: router({
    getNodes: protectedProcedure.query(async () => {
      const nodes = await getAvailableVpnNodes();
      return nodes.map(node => ({
        id: node.id,
        name: node.name,
        region: node.region,
        load: `${node.currentUsers}/${node.maxUsers}`,
        status: node.currentUsers >= node.maxUsers ? "满载" : "在线",
      }));
    }),

    claimNode: protectedProcedure.mutation(async ({ ctx }) => {
      const userId = ctx.user?.id;

      if (!userId) {
        throw new Error("User not authenticated");
      }

      const node = await claimVpnNode(userId);

      if (!node) {
        throw new Error("No available VPN nodes");
      }

      return {
        url: node.configUrl,
        success: true,
      };
    }),
  }),

  // 用户相关
  user: router({
    updateTheme: protectedProcedure
      .input(z.object({ themeColor: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const userId = ctx.user?.id;

        if (!userId) {
          throw new Error("User not authenticated");
        }

        await updateUserTheme(userId, input.themeColor);

        return {
          success: true,
        };
      }),

    getVipStatus: protectedProcedure.query(async ({ ctx }) => {
      const userId = ctx.user?.id;

      if (!userId) {
        throw new Error("User not authenticated");
      }

      const vipStatus = await getUserVipStatus(userId);

      return {
        isVip: vipStatus !== null,
        vipInfo: vipStatus,
      };
    }),

    bindEmail: protectedProcedure
      .input(z.object({ email: z.string().email() }))
      .mutation(async ({ input, ctx }) => {
        // 这里应实现邮箱绑定逻辑
        // 目前只是返回成功
        return {
          success: true,
          message: "邮箱绑定成功",
        };
      }),
  }),

  // 扩展功能路由
  files: extendedRouter.files,
  images: extendedRouter.images,
  code: extendedRouter.code,
  favorites: extendedRouter.favorites,
  apiKeys: extendedRouter.apiKeys,
  toolPreferences: extendedRouter.toolPreferences,

  // 企业级 AI 功能
  enterprise: enterpriseRouter,

  // 流式响应功能
  streaming: streamingRouter,

  // AI 提供商
  ai: router({
    getAvailableProviders: publicProcedure.query(() => {
      return getAvailableProviders();
    }),
  }),
});

export type AppRouter = typeof appRouter;
export { enterpriseRouter, streamingRouter };
