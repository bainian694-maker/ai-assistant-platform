import { trpc } from "@/lib/trpc";

export function useChatApi() {
  const utils = trpc.useUtils();

  const sendMessageMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: () => {
      utils.chat.getHistory.invalidate();
    },
  });

  const getHistoryQuery = trpc.chat.getHistory.useQuery({ limit: 50 });

  return {
    sendMessage: sendMessageMutation.mutateAsync,
    getHistory: getHistoryQuery.data,
    isLoading: sendMessageMutation.isPending,
    isLoadingHistory: getHistoryQuery.isLoading,
  };
}

export function useVpnApi() {
  const getNodesQuery = trpc.vpn.getNodes.useQuery();

  const claimNodeMutation = trpc.vpn.claimNode.useMutation();

  return {
    nodes: getNodesQuery.data,
    claimNode: claimNodeMutation.mutateAsync,
    isLoading: getNodesQuery.isLoading,
    isClaimingNode: claimNodeMutation.isPending,
  };
}

export function useUserApi() {
  const updateThemeMutation = trpc.user.updateTheme.useMutation();

  const getVipStatusQuery = trpc.user.getVipStatus.useQuery();

  const bindEmailMutation = trpc.user.bindEmail.useMutation();

  return {
    updateTheme: updateThemeMutation.mutateAsync,
    getVipStatus: getVipStatusQuery.data,
    bindEmail: bindEmailMutation.mutateAsync,
    isUpdatingTheme: updateThemeMutation.isPending,
    isLoadingVipStatus: getVipStatusQuery.isLoading,
    isBindingEmail: bindEmailMutation.isPending,
  };
}
