import { trpc } from "@/lib/trpc";

// 文件处理 API
export function useFilesApi() {
  const uploadMutation = trpc.files.upload.useMutation();
  const listQuery = trpc.files.list.useQuery();

  return {
    upload: uploadMutation.mutateAsync,
    files: listQuery.data,
    isUploading: uploadMutation.isPending,
    isLoadingFiles: listQuery.isLoading,
  };
}

// 图片生成 API
export function useImagesApi() {
  const generateMutation = trpc.images.generate.useMutation();
  const listQuery = trpc.images.list.useQuery();

  return {
    generate: generateMutation.mutateAsync,
    images: listQuery.data,
    isGenerating: generateMutation.isPending,
    isLoadingImages: listQuery.isLoading,
  };
}

// 代码执行 API
export function useCodeApi() {
  const executeMutation = trpc.code.execute.useMutation();
  const historyQuery = trpc.code.history.useQuery();

  return {
    execute: executeMutation.mutateAsync,
    history: historyQuery.data,
    isExecuting: executeMutation.isPending,
    isLoadingHistory: historyQuery.isLoading,
  };
}

// 对话收藏 API
export function useFavoritesApi() {
  const addMutation = trpc.favorites.add.useMutation();
  const listQuery = trpc.favorites.list.useQuery();

  return {
    add: addMutation.mutateAsync,
    favorites: listQuery.data,
    isAdding: addMutation.isPending,
    isLoadingFavorites: listQuery.isLoading,
  };
}

// API 密钥管理 API
export function useApiKeysApi() {
  const saveMutation = trpc.apiKeys.save.useMutation();
  const listQuery = trpc.apiKeys.list.useQuery();

  return {
    save: saveMutation.mutateAsync,
    apiKeys: listQuery.data,
    isSaving: saveMutation.isPending,
    isLoadingKeys: listQuery.isLoading,
  };
}

// 工具偏好 API
export function useToolPreferencesApi() {
  const saveMutation = trpc.toolPreferences.save.useMutation();
  const listQuery = trpc.toolPreferences.list.useQuery();

  return {
    save: saveMutation.mutateAsync,
    preferences: listQuery.data,
    isSaving: saveMutation.isPending,
    isLoadingPreferences: listQuery.isLoading,
  };
}
