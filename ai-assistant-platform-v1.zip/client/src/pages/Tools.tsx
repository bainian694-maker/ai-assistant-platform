import { useState } from "react";
import { FileUp, Image, Code, Heart, Key, Settings } from "lucide-react";
import { useFilesApi, useImagesApi, useCodeApi, useFavoritesApi, useApiKeysApi } from "@/_core/hooks/useExtendedApi";

const ToolsPage = () => {
  const [activeTab, setActiveTab] = useState("files");
  const { files, isUploading } = useFilesApi();
  const { images, isGenerating } = useImagesApi();
  const { history, isExecuting } = useCodeApi();
  const { favorites } = useFavoritesApi();
  const { apiKeys } = useApiKeysApi();

  const tools = [
    { id: "files", name: "文件处理", icon: FileUp, color: "bg-blue-500" },
    { id: "images", name: "图片生成", icon: Image, color: "bg-purple-500" },
    { id: "code", name: "代码执行", icon: Code, color: "bg-green-500" },
    { id: "favorites", name: "收藏", icon: Heart, color: "bg-red-500" },
    { id: "apikeys", name: "API 密钥", icon: Key, color: "bg-yellow-500" },
    { id: "settings", name: "工具设置", icon: Settings, color: "bg-gray-500" },
  ];

  return (
    <div className="h-full overflow-y-auto bg-white">
      {/* 工具导航 */}
      <div className="grid grid-cols-3 md:grid-cols-6 gap-3 p-4 border-b">
        {tools.map((tool) => {
          const Icon = tool.icon;
          return (
            <button
              key={tool.id}
              onClick={() => setActiveTab(tool.id)}
              className={`flex flex-col items-center gap-2 p-3 rounded-lg transition ${
                activeTab === tool.id
                  ? `${tool.color} text-white`
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              <Icon size={20} />
              <span className="text-xs text-center">{tool.name}</span>
            </button>
          );
        })}
      </div>

      {/* 工具内容 */}
      <div className="p-6 max-w-4xl mx-auto">
        {/* 文件处理 */}
        {activeTab === "files" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">文件处理</h2>
            <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center mb-6">
              <FileUp size={32} className="mx-auto mb-2 text-blue-500" />
              <p className="text-gray-600">拖拽或点击上传文件</p>
              <p className="text-xs text-gray-400 mt-2">支持 PDF, Word, Excel, 图片等格式</p>
            </div>
            {files && files.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-bold">最近文件</h3>
                {files.slice(0, 5).map((file: any) => (
                  <div key={file.id} className="p-3 bg-gray-100 rounded-lg flex justify-between items-center">
                    <span className="text-sm">{file.fileName}</span>
                    <span className="text-xs text-gray-500">{file.fileType}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 图片生成 */}
        {activeTab === "images" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">图片生成</h2>
            <div className="mb-6">
              <textarea
                className="w-full p-4 border rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
                placeholder="输入图片描述..."
                rows={3}
              />
              <button className="mt-3 bg-purple-500 text-white px-6 py-2 rounded-lg hover:bg-purple-600">
                {isGenerating ? "生成中..." : "生成图片"}
              </button>
            </div>
            {images && images.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {images.slice(0, 6).map((img: any) => (
                  <div key={img.id} className="border rounded-lg overflow-hidden">
                    <img src={img.imageUrl} alt={img.prompt} className="w-full h-32 object-cover" />
                    <p className="p-2 text-xs text-gray-600 truncate">{img.prompt}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 代码执行 */}
        {activeTab === "code" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">代码执行</h2>
            <div className="mb-6">
              <select className="w-full p-2 border rounded-lg mb-3">
                <option>Python</option>
                <option>JavaScript</option>
                <option>Bash</option>
              </select>
              <textarea
                className="w-full p-4 border rounded-lg font-mono text-sm focus:ring-2 focus:ring-green-500 outline-none"
                placeholder="输入代码..."
                rows={6}
              />
              <button className="mt-3 bg-green-500 text-white px-6 py-2 rounded-lg hover:bg-green-600">
                {isExecuting ? "执行中..." : "执行代码"}
              </button>
            </div>
            {history && history.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-bold">执行历史</h3>
                {history.slice(0, 5).map((exec: any) => (
                  <div key={exec.id} className="p-3 bg-gray-100 rounded-lg">
                    <p className="text-xs font-mono text-gray-600">{exec.language}</p>
                    <p className="text-sm mt-1">{exec.result?.substring(0, 100)}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 收藏 */}
        {activeTab === "favorites" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">收藏对话</h2>
            {favorites && favorites.length > 0 ? (
              <div className="space-y-3">
                {favorites.map((fav: any) => (
                  <div key={fav.id} className="p-4 border rounded-lg">
                    <p className="font-bold">{fav.title || "未命名"}</p>
                    <p className="text-sm text-gray-600 mt-1">消息 ID: {fav.chatMessageId}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">暂无收藏</p>
            )}
          </div>
        )}

        {/* API 密钥 */}
        {activeTab === "apikeys" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">API 密钥管理</h2>
            <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">添加你的 AI 服务 API 密钥以获得更好的功能支持</p>
            </div>
            <div className="space-y-3 mb-6">
              {["OpenAI", "Anthropic Claude", "Google Gemini"].map((provider) => (
                <div key={provider} className="flex gap-2">
                  <input
                    type="password"
                    placeholder={`${provider} API Key`}
                    className="flex-1 p-2 border rounded-lg"
                  />
                  <button className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                    保存
                  </button>
                </div>
              ))}
            </div>
            {apiKeys && apiKeys.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-bold">已配置的密钥</h3>
                {apiKeys.map((key: any) => (
                  <div key={key.id} className="p-3 bg-gray-100 rounded-lg flex justify-between items-center">
                    <span>{key.provider}</span>
                    <span className={`text-xs px-2 py-1 rounded ${key.isActive ? "bg-green-200 text-green-800" : "bg-gray-200"}`}>
                      {key.isActive ? "活跃" : "禁用"}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 工具设置 */}
        {activeTab === "settings" && (
          <div>
            <h2 className="text-2xl font-bold mb-4">工具设置</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <span>启用文件处理</span>
                <input type="checkbox" defaultChecked className="w-4 h-4" />
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <span>启用图片生成</span>
                <input type="checkbox" defaultChecked className="w-4 h-4" />
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <span>启用代码执行</span>
                <input type="checkbox" defaultChecked className="w-4 h-4" />
              </div>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <span>启用数据分析</span>
                <input type="checkbox" className="w-4 h-4" />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ToolsPage;
