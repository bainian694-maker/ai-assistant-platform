import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { MessageSquare, Globe, Settings, Send, LogOut, Wrench } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { getLoginUrl } from "@/const";
import { useChatApi, useVpnApi, useUserApi } from "@/_core/hooks/useApi";
import ToolsPage from "./Tools";

// AI 对话界面组件
const ChatInterface = () => {
  const { sendMessage, getHistory, isLoading } = useChatApi();
  const [messages, setMessages] = useState([
    { role: "ai", content: "我是 A，已集成全球 AI 算力。请输入指令。" },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (getHistory && getHistory.length > 0) {
      setMessages(getHistory);
    }
  }, [getHistory]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");

    try {
      const response = await sendMessage({ prompt: input });
      setMessages((prev) => [
        ...prev,
        { role: "ai", content: response.content },
      ]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          role: "ai",
          content: "抱歉，请求失败。请稍后重试。",
        },
      ]);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m, i) => (
          <div
            key={i}
            className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[85%] p-4 rounded-2xl ${
                m.role === "user"
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-800"
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 text-gray-800 p-4 rounded-2xl">
              <div className="flex gap-2">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t flex gap-2 mb-16 md:mb-0">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          className="flex-1 p-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
          placeholder="输入指令..."
          disabled={isLoading}
        />
        <button
          onClick={handleSendMessage}
          disabled={isLoading}
          className="bg-blue-600 text-white p-3 rounded-xl hover:bg-blue-700 disabled:opacity-50"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};

// VPN 节点选择界面
const NetworkPage = () => {
  const { nodes, claimNode, isClaimingNode } = useVpnApi();
  const [claimStatus, setClaimStatus] = useState<string | null>(null);

  const handleClaimNode = async () => {
    try {
      const response = await claimNode();
      setClaimStatus(response.url);
    } catch (error) {
      setClaimStatus("领取失败，请检查网络");
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto h-full overflow-y-auto">
      <h2 className="text-2xl font-black mb-2">全域网络体验</h2>
      <p className="text-gray-400 text-sm mb-8">
        购买 VIP 即可领取专属加密节点，直连 AI 核心。
      </p>

      <div className="space-y-4">
        {nodes && nodes.map((node) => (
          <div
            key={node.id}
            className="p-4 border rounded-2xl flex justify-between items-center bg-white shadow-sm"
          >
            <div>
              <p className="font-bold">{node.name}</p>
              <p className="text-xs text-gray-400 font-mono">
                设备数: {node.load}
              </p>
            </div>
            <button
              onClick={handleClaimNode}
              disabled={node.status === "满载" || isClaimingNode}
              className={`px-4 py-2 rounded-xl text-sm font-bold ${
                node.status === "满载"
                  ? "bg-gray-100 text-gray-400"
                  : "bg-blue-600 text-white shadow-md hover:bg-blue-700 disabled:opacity-50"
              }`}
            >
              {isClaimingNode ? "领取中..." : node.status === "满载" ? "已满" : "一键领取"}
            </button>
          </div>
        ))}
      </div>

      {claimStatus && (
        <div className="mt-8 p-4 bg-green-50 border border-green-200 rounded-2xl animate-pulse">
          <p className="text-green-800 text-xs font-bold mb-2 tracking-widest">
            领取成功！配置链接如下：
          </p>
          <code className="block bg-white p-3 border rounded text-[10px] break-all">
            {claimStatus}
          </code>
        </div>
      )}
    </div>
  );
};

// 设置与账户管理界面
const SettingsPage = () => {
  const { user, logout } = useAuth();
  const { updateTheme, getVipStatus, bindEmail, isUpdatingTheme, isBindingEmail } = useUserApi();
  const [email, setEmail] = useState(user?.email || "");
  const [themeColor, setThemeColor] = useState("#2563eb");

  useEffect(() => {
    if (getVipStatus) {
      // VIP 状态已加载
    }
  }, [getVipStatus]);

  const handleEmailBind = async () => {
    if (!email) {
      alert("请输入邮箱地址");
      return;
    }
    try {
      await bindEmail({ email });
      alert("邮箱绑定成功！");
    } catch (error) {
      alert("邮箱绑定失败，请重试");
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      alert("AI 正在分析图片色调并重绘 UI...");
      const newColor = "#7c3aed";
      setThemeColor(newColor);
      try {
        await updateTheme({ themeColor: newColor });
      } catch (error) {
        alert("主题更新失败");
      }
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-8 h-full overflow-y-auto">
      <section>
        <h3 className="font-bold mb-4">账户与同步</h3>
        <div className="flex gap-2">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 p-3 border rounded-xl"
            placeholder="输入邮箱地址"
          />
          <button
            onClick={handleEmailBind}
            disabled={isBindingEmail}
            className="bg-black text-white px-6 rounded-xl text-sm hover:bg-gray-800 disabled:opacity-50"
          >
            {isBindingEmail ? "绑定中..." : "绑定"}
          </button>
        </div>
      </section>

      <section className="p-6 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-3xl text-white">
        <p className="text-xs font-bold opacity-80 uppercase">VIP Membership</p>
        <h4 className="text-2xl font-black mt-1">
          {getVipStatus?.isVip ? "已激活 VIP" : "解锁无限 AI 流量"}
        </h4>
        <button className="mt-4 bg-white text-orange-600 px-6 py-2 rounded-full font-bold text-sm shadow-xl hover:shadow-2xl">
          {getVipStatus?.isVip ? "管理订阅" : "立即升级"}
        </button>
      </section>

      <section>
        <h3 className="font-bold mb-4">界面改写 (AI 驱动)</h3>
        <div
          style={{ borderColor: themeColor }}
          className="border-2 border-dashed p-10 rounded-3xl text-center cursor-pointer hover:bg-gray-50 transition"
          onClick={() => document.getElementById("fileInput")?.click()}
        >
          <p className="text-sm text-gray-500">
            点击上传图片，A 将自动为您重塑软件视觉系统
          </p>
          <input
            id="fileInput"
            type="file"
            className="hidden"
            onChange={handleImageUpload}
            accept="image/*"
            disabled={isUpdatingTheme}
          />
        </div>
      </section>

      <section className="border-t pt-6">
        <button
          onClick={logout}
          className="w-full bg-red-600 text-white p-3 rounded-xl hover:bg-red-700 flex items-center justify-center gap-2"
        >
          <LogOut size={20} />
          退出登录
        </button>
      </section>
    </div>
  );
};

// 导航栏组件
const Navbar = ({ currentPage, setCurrentPage }: any) => (
  <nav className="fixed bottom-0 w-full bg-white border-t flex justify-around p-3 md:relative md:w-24 md:h-screen md:flex-col md:border-t-0 md:border-r md:justify-start md:space-y-10 md:pt-10 z-50">
    <button
      onClick={() => setCurrentPage("chat")}
      className={`flex flex-col items-center text-gray-600 hover:text-blue-600 ${
        currentPage === "chat" ? "text-blue-600" : ""
      }`}
    >
      <MessageSquare size={24} />
      <span className="text-[10px] mt-1">智能 A</span>
    </button>
    <button
      onClick={() => setCurrentPage("tools")}
      className={`flex flex-col items-center text-gray-600 hover:text-green-600 ${
        currentPage === "tools" ? "text-green-600" : ""
      }`}
    >
      <Wrench size={24} />
      <span className="text-[10px] mt-1">工具</span>
    </button>
    <button
      onClick={() => setCurrentPage("network")}
      className={`flex flex-col items-center text-gray-600 hover:text-blue-600 ${
        currentPage === "network" ? "text-blue-600" : ""
      }`}
    >
      <Globe size={24} />
      <span className="text-[10px] mt-1">全域网</span>
    </button>
    <button
      onClick={() => setCurrentPage("settings")}
      className={`flex flex-col items-center text-gray-600 hover:text-blue-600 ${
        currentPage === "settings" ? "text-blue-600" : ""
      }`}
    >
      <Settings size={24} />
      <span className="text-[10px] mt-1">设置</span>
    </button>
  </nav>
);

// 主页面
export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState("chat");
  const [, navigate] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>加载中...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="text-center max-w-md">
          <h1 className="text-4xl font-black mb-4 text-blue-600">A</h1>
          <p className="text-xl font-bold mb-2">全球 AI 集成助手</p>
          <p className="text-gray-600 mb-8">
            集成全球最强 AI 算力，一键完成任何任务
          </p>
          <Button
            onClick={() => navigate(getLoginUrl())}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg font-bold rounded-xl"
          >
            登录开始使用
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col md:flex-row h-screen overflow-hidden bg-white">
      <Navbar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <div className="flex-1 h-full relative">
        {currentPage === "chat" && <ChatInterface />}
        {currentPage === "tools" && <ToolsPage />}
        {currentPage === "network" && <NetworkPage />}
        {currentPage === "settings" && <SettingsPage />}
      </div>
    </div>
  );
}
